def testlog():
    print("Py-logging is up!")
