def test():
    print("Py-logging is up!")