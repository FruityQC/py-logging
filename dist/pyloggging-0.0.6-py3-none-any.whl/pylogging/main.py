def testlog():
    return "Pylogging working !"
